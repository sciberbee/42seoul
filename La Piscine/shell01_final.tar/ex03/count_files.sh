find . | wc -l | sed 's/ //g'
