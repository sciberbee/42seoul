git --no-pager log -n 5 --pretty=%H
