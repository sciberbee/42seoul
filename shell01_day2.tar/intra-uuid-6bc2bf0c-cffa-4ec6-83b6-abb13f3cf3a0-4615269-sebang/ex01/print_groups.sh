id -nG $FT_USER | tr ' ' ','
