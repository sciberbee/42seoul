ifconfig | grep -E '\sether' | sed $'s/^\tether//'
